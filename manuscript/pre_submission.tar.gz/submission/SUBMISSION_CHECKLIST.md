# Physical Review E — submission checklist

Submit at <https://authors.aps.org/Submissions/> (journal: Physical Review E).
Fresh submission; nothing here is a revision.

| APS requirement | File |
|---|---|
| Manuscript, REVTeX 4.2 source + compiled PDF | `main.tex` + `main.pdf` (15 pp, `pre,reprint`; bibliography is an inline `thebibliography`, so no `.bib`/`.bbl`) |
| Figures as separate files | `figures/fig_schematic.pdf`, `fig_readout.pdf`, `fig_criterion.pdf` — all vector |
| Supplemental Material (separate PDF) | `supplementary.pdf` (11 pp; source `supplementary.tex`, also REVTeX). The paper carries the required "See Supplemental Material at [URL] for ..." sentence in its Data and code availability section; the publisher inserts the URL |
| Data availability statement | `\section*{Data and code availability}` in `main.tex`; the standalone `data_availability.pdf` is the same statement with the module-by-module detail |
| Cover letter | `cover_letter.pdf` (what the paper does, why PRE, AI-tool disclosure, no competing interests, repository URL) |
| AI-tool disclosure | Appendix B of the manuscript (workflow and representative prompts) and the Acknowledgments (every model and version); repeated in the cover letter |
| Author contributions | `\section*{Author contributions}` in `main.tex` |

`FREEZE_MANIFEST.txt` is included so that every file in the bundle can be hashed
against the state the tests were run in; `scripts/make_bundle.sh` does that check
before packing and refuses to build unless `scripts/release_check.sh` passes.

## Suggested referees (also written into the cover letter; verified affiliations marked ✓; check emails against the cited papers' corresponding-author lines)

| | Affiliation | Why |
|---|---|---|
| Daniel R. Kattnig | University of Exeter ✓ | relaxation-explicit radical-pair master equations; Wong–Solov'yov–Hore–Kattnig (JCP 2021) is the closest prior art to the register argument |
| Jörg Matysik | Leipzig University ✓ | photo-CIDNP in flavoproteins; can judge whether the product polarisation is a readout |
| P. J. Hore | University of Oxford ✓ | the Haberkorn/weak-field framework; also the Posner-qubit spin-dynamics analysis (note: same lineage as Kattnig) |
| Joni Dambre | Ghent University (unverified) | author of the IPC bound the paper uses as its correctness anchor |
| Michael R. Wasielewski | Northwestern University ✓ | molecular quantum information science; the framing of spin chemistry as a computational resource |

Reserves: Miguel C. Soriano (IFISC ✓, quantum reservoir computing), Bertil Halle
(Lund ✓, the cross-relaxation work the bath calibration leans on), Ilia A.
Solov'yov (Oldenburg ✓, computational cryptochrome).

## Still to do in the APS portal

- Link the corresponding author's ORCID (H. Wakaura: 0000-0001-8381-8323).
- Enter the suggested referees above with their emails (the cover letter lists
  Kattnig, Matysik, Hore, Wasielewski and Soriano, with Halle and Solov'yov as
  alternates, and asks that C. M. Kerskens not be used).
- PRE has no APC for standard publication; choose open access only if wanted.

## What the repository carries

Public `deeptell-inc/new_Q_brain`: code, data, figures and the compiled
`main.pdf`, `supplementary.pdf`, `data_availability.pdf`. The LaTeX sources,
cover letter and this checklist live in the private manuscript repository
(`scripts/mgit.sh`). The Data and code availability section says so.

## Decisions recorded

- Venue: Physical Review E (chosen over PRX Life; PCCP is closed to this paper
  after CP-ART-06-2026-002404 and CP-ART-08-2026-003312).
- Flavin hyperfine couplings aligned with the companion study's set
  (N5 = 14.66, N10 = 5.30 MHz); every cryptochrome-point number regenerated.
- The companion (now *Catalytic competence bounds the decay rates of a thermally
  formed radical pair*, under review at J. Chem. Phys.) is not cited until it is
  public.
- The cryptochrome point's J = 0 / no-dipole premise is stated as a premise and
  its dependence computed (Sec. "What depends on the coupling premise",
  Supplemental Material S14).

## Rebuilding

```
bash scripts/make_bundle.sh
```

Writes `manuscript/submission/` and `manuscript/pre_submission.tar.gz`. The
bundle is not committed: it is derivable, and a committed copy goes stale. Run
it immediately before uploading.
