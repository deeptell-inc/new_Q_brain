# The Journal of Chemical Physics — submission checklist

Submit at <https://jcp.peerx-press.org/> (AIP Publishing). Fresh submission;
nothing here is a revision.

| AIP requirement | File |
|---|---|
| Manuscript PDF (source requested at acceptance) | `main.pdf` (REVTeX 4.2, `aip,jcp,reprint`; bibliography is an inline `thebibliography`, so no `.bib`/`.bbl`) |
| Figures as separate files | `figures/fig_schematic.pdf`, `fig_readout.pdf`, `fig_criterion.pdf` — all vector |
| Supplementary material (separate PDF) | `supplementary.pdf` (source `supplementary.tex`, also REVTeX). The paper carries the "See the supplementary material for ..." section listing every supplement section |
| Author declarations | `\section*{Author declarations}` in `main.tex`: Conflict of interest (none) and Author contributions |
| Data availability statement | `\section*{Data availability}` in `main.tex`; the standalone `data_availability.pdf` is the same statement with the module-by-module detail |
| Cover letter | `cover_letter.pdf` (what the paper does, why JCP, AI-tool disclosure, no competing interests, repository URL, suggested referees) |
| AI-tool disclosure | Appendix B of the manuscript (workflow and representative prompts) and the Acknowledgments (every model and version); repeated in the cover letter |

`FREEZE_MANIFEST.txt` is included so that every file in the bundle can be hashed
against the state the tests were run in; `scripts/make_bundle.sh` does that check
before packing and refuses to build unless `scripts/release_check.sh` passes.

## Suggested reviewers (four for the portal; emails verified on institutional pages or corresponding-author lines, 2026-10-20)

| | Affiliation | Email | Why |
|---|---|---|---|
| Daniel R. Kattnig | University of Exeter, Physics and Astronomy / Living Systems Institute | D.R.Kattnig@exeter.ac.uk | relaxation-explicit radical-pair master equations; Wong–Solov'yov–Hore–Kattnig (JCP 2021) is the closest prior art |
| Jörg Matysik | Leipzig University, Institute of Analytical Chemistry | joerg.matysik@uni-leipzig.de | photo-CIDNP in flavoproteins; can judge whether the product polarisation is a readout |
| Michael R. Wasielewski | Northwestern University, Department of Chemistry | m-wasielewski@northwestern.edu | molecular quantum information science; spin chemistry as a computational resource |
| Miguel C. Soriano | IFISC (CSIC-UIB), Mallorca | miguel@ifisc.uib-csic.es | quantum reservoir computing; the capacity and classical-baseline methodology |

Alternates: P. J. Hore (University of Oxford, peter.hore@chem.ox.ac.uk; same lineage as Kattnig), Bertil Halle (Lund; the cross-relaxation work the bath calibration leans on), Ilia A. Solov'yov (Oldenburg; computational cryptochrome). Non-preferred: C. M. Kerskens.

## Still to do in the AIP portal

- Link the corresponding author's ORCID (H. Wakaura: 0000-0001-8381-8323).
- Enter the four suggested reviewers above (the cover letter lists Kattnig,
  Matysik, Hore, Wasielewski and Soriano, with Halle and Solov'yov as alternates,
  and asks that C. M. Kerskens not be used).
- Article type: regular article (not a Communication; no length limit applies).
- JCP has no APC for standard publication; choose open access only if wanted.

## What the repository carries

Public `deeptell-inc/new_Q_brain`: code, data, figures and the compiled
`main.pdf`, `supplementary.pdf`, `data_availability.pdf`. The LaTeX sources,
cover letter and this checklist live in the private manuscript repository
(`scripts/mgit.sh`). The Data availability section says so.

## Decisions recorded

- Venue: The Journal of Chemical Physics. Physical Review E declined at the
  editorial stage without review; PCCP is closed to this paper after
  CP-ART-06-2026-002404 and CP-ART-08-2026-003312.
- Flavin hyperfine couplings aligned with the companion study's set
  (N5 = 14.66, N10 = 5.30 MHz); every cryptochrome-point number regenerated.
- The companion (now *Catalytic competence bounds the decay rates of a thermally
  formed radical pair*, under review at J. Chem. Phys.) is not cited until it is
  public.
- The cryptochrome point's J = 0 / no-dipole premise is stated as a premise and
  its dependence computed (Sec. "What depends on the coupling premise",
  supplementary material S14).

## Rebuilding

```
bash scripts/make_bundle.sh
```

Writes `manuscript/submission/` and `manuscript/jcp_submission.tar.gz`. The
bundle is not committed: it is derivable, and a committed copy goes stale. Run
it immediately before uploading.
